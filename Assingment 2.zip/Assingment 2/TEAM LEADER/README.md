# flask-with-sqlite

Clone this Repo

```
git clone git@github.com:kshyam/flask-with-sqlite.git
cd flask-with-sqlite
```

Or Download form Zip

```
https://github.com/kshyam/flask-with-sqlite/archive/refs/heads/main.zip

```

cd flask-with-sqlite

> Create Database using Python Sctipt

``` 
python sqlite_db_setup.py
```

Start you Flask App in debug mode

``` 
flask --debug run
```

Open all at 

```
http://localhost:5000/

```
